export interface Profesional {
  id: number;
  firstName: string;
  lastName: string;
  profession: string;
  pictureBase64: null;
  picture: string;
  working_days: string;
  active: boolean;
}
