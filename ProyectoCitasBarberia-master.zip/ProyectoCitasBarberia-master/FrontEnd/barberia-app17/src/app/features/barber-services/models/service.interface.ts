export interface Service {
  id: number;
  name: string;
  description: string;
  price: number;
  durationMinutes: number;
}
