export const environment = {
  production: false,
  apiUrl: 'http://localhost:8190/api',
  url: 'http://localhost:8190',
};
