package com.barbershop.model;

import lombok.Data;

@Data
public class Auth {

	private String email;
	private String password;
	
}
